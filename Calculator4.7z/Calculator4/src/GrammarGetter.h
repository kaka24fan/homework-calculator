#pragma once
#include "Enums.h"
#include "Production.h"
#include "Grammar.h"

#include <string>

Grammar getGrammar(std::string path);
