#pragma once

void testLexer();