#pragma once
#include<string>

int digitVal(char c);
bool isDigit(char c);
bool isWhitespace(char c);
std::string int_to_string(int n);
