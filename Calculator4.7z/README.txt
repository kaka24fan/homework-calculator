﻿You can put input to the calculator in the file Calculator4/src/input.txt
where you will find formatting instructions waiting for you.

You can also give input line by line in the console.